import { getStore } from "@netlify/blobs";

const store = getStore("r-fragancias-settings");

export default async (request) => {
  if (request.method === "GET") {
    const settings = await store.get("public-settings", { type: "json" }) || { whatsapp: "", storeName: "R Fragancias" };
    return Response.json({ whatsapp: settings.whatsapp || "", storeName: settings.storeName || "R Fragancias" }, { headers: { "Cache-Control": "no-store" } });
  }
  if (request.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected) return Response.json({ error: "Falta configurar ADMIN_PASSWORD en Netlify." }, { status: 503 });
  let body;
  try { body = await request.json(); } catch { return Response.json({ error: "Solicitud inválida." }, { status: 400 }); }
  if (typeof body.password !== "string" || body.password !== expected) return Response.json({ error: "Contraseña incorrecta." }, { status: 401 });
  if (body.action === "verify") return Response.json({ ok: true });
  const whatsapp = String(body.whatsapp || "").replace(/\D/g, "");
  const storeName = String(body.storeName || "R Fragancias").trim().slice(0, 80) || "R Fragancias";
  if (whatsapp.length < 10 || whatsapp.length > 15) return Response.json({ error: "Escribe el número completo con indicativo de país, solo números." }, { status: 400 });
  await store.setJSON("public-settings", { whatsapp, storeName, updatedAt: new Date().toISOString() });
  return Response.json({ ok: true, whatsapp, storeName });
};
