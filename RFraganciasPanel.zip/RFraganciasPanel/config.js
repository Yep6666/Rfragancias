// CONFIGURACIÓN DE R FRAGANCIAS
// Cambia el número por el WhatsApp del negocio, con indicativo y solo números.
// Colombia: 57 + número de celular. Ejemplo ficticio: 573001234567
window.RF_CONFIG = {
  whatsapp: "",
  storeName: "R Fragancias"
};
